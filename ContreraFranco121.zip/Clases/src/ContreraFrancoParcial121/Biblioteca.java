package ContreraFrancoParcial121;

import java.util.HashSet;
import java.util.Set;

public class Biblioteca {

    private Set<Publicacion> publicaciones;

    public Biblioteca() {
        this.publicaciones = new HashSet<>();
    }

    public void agregarPublicacion(Publicacion p) throws PublicacionDuplicadaException {
        if (!publicaciones.add(p)) {
            throw new PublicacionDuplicadaException("La publicacion ya esta agregada");
        }
    }
    
    public void mostrarPublicaciones() {
        for (Publicacion p : publicaciones) {
            System.out.println(p.toString());
        }
    }

    public void leerPublicaciones() {
        for (Publicacion p : publicaciones) {
            System.out.println(p.leer());
        }
    }
}