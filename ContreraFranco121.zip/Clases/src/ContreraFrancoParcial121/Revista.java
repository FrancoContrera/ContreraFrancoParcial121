package ContreraFrancoParcial121;

public class Revista extends Publicacion {
    private int numeroEdicion;

    public Revista(String titulo, int anioPublicacion, int numeroEdicion) {
        super(titulo, anioPublicacion);
        this.numeroEdicion = numeroEdicion;
    }

    public int getNumeroEdicion() {
        return numeroEdicion;
    }

    @Override
    public String leer() {
        return "Se esta leyendo la revista: " + getTitulo();
    }

    @Override
    public String toString() {
        return "Revista [numeroEdicion=" + numeroEdicion + "]";
    }
}
