package ContreraFrancoParcial121;

import java.util.Objects;

public abstract class Publicacion {
	private String titulo;
	private int anioPublicacion;
	
	public Publicacion(String titulo, int anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }
	
	public String getTitulo() {
        return titulo;
    }
	
	public int getAnioPublicacion() {
        return anioPublicacion;
    }
	
	public abstract String leer();
	
	@Override
	public String toString() {
        return "Título: " + titulo + ", Año de Publicación: " + anioPublicacion;
    }
	
	@Override
	public boolean equals(Object obj) {
		if(this == obj) return true;
		if (obj == null || getClass() != obj.getClass()) return false;
		Publicacion otraPublicacion = (Publicacion) obj;
		return anioPublicacion == otraPublicacion.anioPublicacion && titulo.equals(otraPublicacion.getTitulo());
	}
	
	@Override
    public int hashCode() {
        return Objects.hash(titulo, anioPublicacion);
    }
}
