package ContreraFrancoParcial121;

public class TestBiblioteca {
	public static void main(String[] args) {
		Biblioteca biblioteca = new Biblioteca();
		
		Libro libro1 = new Libro("Argentina2001", 2001, "Roberto Juan PErez", Genero.HISTORIA);
		Revista revista1 = new Revista("Revista Caras", 2022, 5);
		Ilustracion ilustracion1 = new Ilustracion("La Monalisa", 1430, "DaVinci", 50.5, 40.2);
		
		try {
			biblioteca.agregarPublicacion(libro1);
            biblioteca.agregarPublicacion(revista1);
            biblioteca.agregarPublicacion(ilustracion1);
            
            biblioteca.agregarPublicacion (new Libro("Argentina2001", 2001, "Roberto Juan PErez", Genero.HISTORIA));
        } catch (PublicacionDuplicadaException e) {
            System.out.println(e.getMessage());
        }
		
		System.out.println("\nPublicaciones en la biblioteca:");
		biblioteca.mostrarPublicaciones();
		
		System.out.println("\nLeyendo publicaciones en la biblioteca:");
		biblioteca.leerPublicaciones();
	}

}
