package ContreraFrancoParcial121;

public enum Genero {
	FICCION, NO_FICCION, CIENCIA, HISTORIA

}
