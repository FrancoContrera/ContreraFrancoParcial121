package ContreraFrancoParcial121;

class PublicacionDuplicadaException extends Exception {
    public PublicacionDuplicadaException(String mensaje) {
        super(mensaje);
    }
}
