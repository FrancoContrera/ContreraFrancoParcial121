package ContreraFrancoParcial121;

public class Ilustracion extends Publicacion {
	private String nombreIlustrador;
	private double ancho;
	private double alto;
	
	public Ilustracion(String titulo, int anioPublicacion, String nombreIlustrador, double ancho, double alto) {
		super(titulo, anioPublicacion);
		this.nombreIlustrador = nombreIlustrador;
		this.ancho = ancho;
		this.alto = alto;
	}
	
	public String getNombreIlustrador() {
        return nombreIlustrador;
    }
	
	public double getAncho() {
        return ancho;
    }
	
	public double getAlto() {
        return alto;
    }
	
	@Override
	public String leer() {
	    return "La ilustración no se puede leer.";
	}
	
	@Override
	public String toString() {
	    return "Ilustracion [ilustrador=" + nombreIlustrador + ", ancho=" + ancho + ", alto=" + alto + "]";
	}

}
